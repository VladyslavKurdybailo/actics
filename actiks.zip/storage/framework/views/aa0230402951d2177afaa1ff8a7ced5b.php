<!-- resources/views/layouts/app.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мій сайт</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<!-- Бокова панель -->
<div id="sidebar" class="sidebar">
    <button id="toggle-sidebar" class="toggle-btn">☰</button>
    <ul>
        <li><a href="<?php echo e(route('dashboard')); ?>">Дашборд</a></li>
        <li><a href="<?php echo e(route('acts.index')); ?>">Переглянути акти</a></li>
        <li><a href="<?php echo e(route('acts.create')); ?>">Створити акт</a></li>
        <li><a href="<?php echo e(route('acts.import')); ?>">Імпортувати акти</a></li>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-btn">Вийти</button>
        </form>
    </ul>
</div>

<!-- Головний контент -->
<div class="main-content">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\OSPanel\home\actiks\actiks\resources\views/layouts/app.blade.php ENDPATH**/ ?>
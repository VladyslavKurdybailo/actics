<!-- resources/views/acts/index.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Список актів</h1>

    <!-- Таблиця для відображення актів -->
    <table>
        <thead>
        <tr>
            <th>id</th>
            <th>Номер акту</th>
            <th>Замовник</th>
            <th>Результат</th>
            <th>Статус</th>
            <th>Дії</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($act->id); ?></td>
                <td><?php echo e($act->act_number); ?></td>
                <td><?php echo e($act->customer_name); ?></td>
                <td><?php echo e($act->conclusion); ?></td>
                <td>
                    <?php if($act->signed_pdf_path): ?>
                        <span style="color: green;">Підписано</span>
                    <?php else: ?>
                        <span style="color: red;">Не підписано</span>
                    <?php endif; ?>
                </td>
                <td>
                    <!-- Кнопка для перегляду акту -->
                    <a href="<?php echo e(route('acts.show', $act->id)); ?>">Переглянути</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OSPanel\home\actiks\actiks\resources\views/acts/index.blade.php ENDPATH**/ ?>
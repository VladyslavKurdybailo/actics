<!-- resources/views/dashboard.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="dashboard-container">
        <h1>Статистика по актам</h1>

        <div class="dashboard-stats">
            <div class="stat-card">
                <h3>Загальна кількість актів</h3>
                <p><?php echo e($totalActs); ?></p>
            </div>
            <div class="stat-card">
                <h3>Підписано</h3>
                <p><?php echo e($signedActs); ?></p>
            </div>
            <div class="stat-card">
                <h3>Не підписано</h3>
                <p><?php echo e($unsignedActs); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OSPanel\home\actiks\actiks\resources\views/dashboard.blade.php ENDPATH**/ ?>
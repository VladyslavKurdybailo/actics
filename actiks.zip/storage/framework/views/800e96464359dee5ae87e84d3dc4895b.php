<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Імпорт актів з Google Таблиці</h1>

        <!-- Повідомлення про імпорт -->
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <!-- Форма для запуску імпорту -->
        <form action="<?php echo e(route('acts.import.process')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Запустити імпорт</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OSPanel\home\actiks\actiks\resources\views/acts/import.blade.php ENDPATH**/ ?>
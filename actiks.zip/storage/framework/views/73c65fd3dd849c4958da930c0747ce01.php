<!-- resources/views/acts/show.blade.php -->



<?php $__env->startSection('content'); ?>
<h1>Акт перевірки № <?php echo e($act->id); ?></h1>
<p><strong>Дата:</strong> <?php echo e($act->date); ?></p>
<p><strong>Час:</strong> <?php echo e($act->time); ?></p>
<p><strong>Результат:</strong> <?php echo e($act->result); ?></p>


<?php if(!$act->signed_pdf_path): ?> <!-- Якщо акт не підписано -->
<h3>Завантажити PDF:</h3>
<a href="<?php echo e(asset('storage/acts/' . basename($act->pdf_path))); ?>" download>Завантажити Акт на підпис</a>
<?php endif; ?>

<h3>QR-код:</h3>
<img src="<?php echo e(asset('storage/qrcodes/' . basename($act->qr_code))); ?>" alt="QR-код">

<?php if($act->signed_pdf_path): ?> <!-- Якщо акт підписано -->
<h3>Акт підписано</h3>
<p>Переглянути підписаний акт:</p>
<a href="<?php echo e(asset('storage/signed_acts/' . basename($act->signed_pdf_path))); ?>" download>Завантажити підписаний акт</a>
<?php else: ?> <!-- Якщо акт не підписано -->
<h3>Завантажити підписаний акт:</h3>
<form action="<?php echo e(route('acts.uploadSigned', $act->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="signed_pdf" required>
    <button type="submit">Завантажити підписаний акт</button>
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OSPanel\home\actiks\actiks\resources\views/acts/show.blade.php ENDPATH**/ ?>